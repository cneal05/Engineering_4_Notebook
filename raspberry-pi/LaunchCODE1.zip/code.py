import time
for counter in range(10, 0, -1):
    print(counter)
    time.sleep(1)
print("Liftoff!")